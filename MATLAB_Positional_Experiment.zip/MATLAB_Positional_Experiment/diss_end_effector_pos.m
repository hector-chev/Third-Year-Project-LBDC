clearvars;
clc;
close all;
data = readtable("123456789.csv");
t = data.pc_time_ms/1000;

x_desired = data.cam_x;
y_desired = data.cam_y;
z_desired = data.cam_z;
x_actual = (data.arduino_x)*30/47; % inverting the transformation applied in the Arduino Mega Code
y_actual = (data.arduino_y*(35/47))-19;% inverting the transformation applied in the Arduino Mega Code
z_actual = data.arduino_z-17.5;% inverting the transformation applied in the Arduino Mega Code

% --- Figure 1: 3D Plot ---
figure(1);
hold on;
grid on;
plot3(x_desired, y_desired, z_desired, 'b-', 'DisplayName', 'Hand Position');
plot3(x_actual, y_actual, z_actual, 'r-', 'DisplayName', 'End-Effector Position');
view(3);
xlabel('X', 'FontSize', 18);
ylabel('Y', 'FontSize', 18);
zlabel('Z', 'FontSize', 18);
title('3D Trajectory', 'FontSize', 50);
ax = gca;
ax.FontSize = 14;  % tick numbers
legend('Hand Position', 'End-Effector Position', 'FontSize', 16, 'Location', 'best');

% --- Figure 2: X vs Time ---
figure(2);
hold on;
grid on;
plot(t, x_desired, 'b-');
plot(t, x_actual, 'r-');
ylabel('X (cm)', 'FontSize', 18);
xlabel('Time (s)', 'FontSize', 18);
title('X Position vs Time', 'FontSize', 50);
ax = gca;
ax.FontSize = 14;
legend('Hand Position', 'End-Effector Position', 'FontSize', 16, 'Location', 'best');

% --- Figure 3: Y vs Time ---
figure(3);
hold on;
grid on;
plot(t, y_desired, 'b-');
plot(t, y_actual, 'r-');
ylabel('Y (cm)', 'FontSize', 18);
xlabel('Time (s)', 'FontSize', 18);
title('Y Position vs Time', 'FontSize', 50);
ax = gca;
ax.FontSize = 14;
legend('Hand Position', 'End-Effector Position', 'FontSize', 16, 'Location', 'best');

% --- Figure 4: Z vs Time ---
figure(4);
hold on;
grid on;
plot(t, z_desired, 'b-');
plot(t, z_actual, 'r-');
ylabel('Z (cm)', 'FontSize', 18);
xlabel('Time (s)', 'FontSize', 18);
title('Z Position vs Time', 'FontSize', 50);
ax = gca;
ax.FontSize = 14;
legend('Hand Position', 'End-Effector Position', 'FontSize', 16, 'Location', 'best');